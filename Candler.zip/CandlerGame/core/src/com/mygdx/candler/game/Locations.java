package com.mygdx.candler.game;

public enum Locations {
    MainMenu,
    Game,
    Settings
}
